var config = {

config: {

mixins: {

'Magento_Catalog/js/catalog-add-to-cart': {

'General_St8/js/catalog-add-to-cart': true

}

}

}

};
