<?php
namespace General\St12\Observer;

use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class blocked implements ObserverInterface
{   protected $productCollection;
    public function execute(Observer $observer)
    {
        $productCollection = $observer->getEvent()->getCollection()->addAttributeToFilter('type_id', 'configurable');
    }
}
