<?php
namespace General\St5\Observer;
use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
class CatalogProductListCollectionObserver implements ObserverInterface
{
    public function execute(EventObserver $observer)
    {
        $productCollection = $observer->getEvent()->getCollection();
        $productCollection->addAttributeToFilter('price', ['lteq' => 100]);
        return $this;
    }
}
