<?php
declare(strict_types=1);

namespace Advance\At11\Plugin;

use Magento\Customer\Model\Session;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\View\Element\Template\Context;

/**
 * class for changing product price
 */
class Product
{
    protected Session $customersession;
    protected $customerSession;

    public function __construct(
        Context $context,
        Session $customerSession,
        array   $data = []
    )
    {
        $this->customerSession = $customerSession;
    }

    public function getCustomerId()
    {
        $customerId = '';
        if ($this->customerSession->isLoggedIn()) {
            $customerId = $this->customerSession->getCustomer()->getId();
        }
        return $customerId;
    }

    public function afterGetPrice(\Magento\Catalog\Model\Product $subject, $result)
    {
        $om = ObjectManager::getInstance();
        $customerSession = $om->get('Magento\Customer\Model\Session');
        $customerId = $customerSession->getCustomer()->getId();//get id of customer
        if ($customerId == 5) {
            $getPrice = $result;
            $getPrice = $getPrice / 100;
            $getPrice = $getPrice * 20;
            return $result + $getPrice;
        }
        return $result;
    }
}
