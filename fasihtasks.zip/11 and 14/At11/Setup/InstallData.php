<?php

namespace Advance\At11\Setup;

use Magento\Customer\Model\GroupFactory;
use Magento\Framework\Setup\InstallDataInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\ModuleDataSetupInterface;

class InstallData implements InstallDataInterface
{
    protected $groupFactory;

    public function __construct(GroupFactory $groupFactory)
    {
        $this->groupFactory = $groupFactory;
    }

    public function install(
        ModuleDataSetupInterface $setup,
        ModuleContextInterface   $context
    ) {
        $setup->startSetup();

        $group = $this->groupFactory->create();
        $group
            ->setCode('Special Customers')
            ->setTaxClassId(5)->save();

        $setup->endSetup();
    }
}
