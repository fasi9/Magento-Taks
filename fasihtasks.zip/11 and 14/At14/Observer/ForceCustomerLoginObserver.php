<?php
declare(strict_types=1);

namespace Advance\At14\Observer;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Response\RedirectInterface;
use Magento\Framework\Event\Observer;
use Magento\Framework\Event\ObserverInterface;

class ForceCustomerLoginObserver implements ObserverInterface
{
    protected $redirect;

    public function __construct(
        RedirectInterface $redirect
    ) {
        $this->redirect = $redirect;
    }

    /**
     * Redirect to login page
     *
     * @param Observer $observer
     * @return $this
     */
    public function execute(Observer $observer)
    {
        /** @var Action $controller */
        $controller = $observer->getControllerAction();
        $this->redirect->redirect($controller->getResponse(), 'customer/account/login');

        return $this;
    }
}
