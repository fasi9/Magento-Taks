<?php
declare(strict_types=1);

namespace Advance\At12\Cron;

use Psr\Log\LoggerInterface;
use Zend\Log\Logger;
use Zend\Log\Writer\Stream;

class SampleCron
{

    public function execute()
    {

        $writer = new Stream(BP . '/var/log/cron.log');
        $logger = new Logger();
        $logger->addWriter($writer);
        $logger->info(__METHOD__);

        return $this;

    }
}
