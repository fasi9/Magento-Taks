<?php

namespace Advance\At10\Logger;

class Logger extends \Monolog\Logger
{

}
