<?php
declare(strict_types=1);

namespace Advance\At10\Model;

use Advance\At10\Logger\Logger;

class MyModel
{
    /**
     * Logging instance
     * @var Logger
     */
    protected $logger;

    /**
     * Constructor
     * @param Logger $logger
     */
    public function __construct(
        Logger $logger
    ) {
        $this->logger = $logger;
    }

    public function doSomething()
    {
        $this->logger->info('I did something');
    }
}
