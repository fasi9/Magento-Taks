<?php
declare(strict_types=1);

namespace Advance\At15\Plugin;

use Magento\Catalog\Ui\DataProvider\Product\ProductDataProvider;

/**
 * Class
 */
class ProductFilter
{
    /**
     * @param ProductDataProvider $dataProvider
     * @return array
     */
    public function afterGetData(ProductDataProvider $dataProvider)
    {
        if ($dataProvider->getCollection()->clear()) {

            $dataProvider->getCollection()->addFieldToFilter('entity_id', ['gt' => 1100])->toArray();
            $items = $dataProvider->getCollection()->addFieldToFilter('entity_id', ['lt' => 1300])->toArray();
        }
        return [
            'totalRecords' => $dataProvider->getCollection()->getSize(),
            'items' => array_values($items),
        ];
    }
}
