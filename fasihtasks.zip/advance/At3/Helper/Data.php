<?php

declare(strict_types=1);

namespace Advance\At3\Helper;

use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Store\Model\ScopeInterface;

class Data extends AbstractHelper
{
    /**
     * Extension enabled config path
     */
    protected const XML_PATH_NO_WELCOME_EMAIL = 'at3/create_account/welcome_email_disable';
    protected $scopeConfig;

    /**
     * Constructor
     *
     * @param ScopeConfigInterface $scopeConfig
     */
    public function __construct(
        ScopeConfigInterface $scopeConfig
    ) {
        $this->scopeConfig = $scopeConfig;
    }

    /**
     * Retrieve true if extension is enabled.
     *
     * @return bool
     */
    public function moduleEnabled()
    {
        return (bool)$this->scopeConfig->getValue(
            self::XML_PATH_NO_WELCOME_EMAIL,
            ScopeInterface::SCOPE_STORE
        );
    }
}
