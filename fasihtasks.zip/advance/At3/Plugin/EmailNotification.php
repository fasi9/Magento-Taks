<?php
declare(strict_types=1);

namespace Advance\At3\Plugin;

use Advance\At3\Helper\Data;
use Closure;

class EmailNotification
{
    public function __construct(
        Data $moduleEnable
    ) {
        $this->moduleEnable = $moduleEnable;
    }

    public function aroundNewAccount(\Magento\Customer\Model\EmailNotification $subject, Closure $proceed)
    {
        if ($this->moduleEnable->moduleEnabled() == 1) {
            return $subject;
        }
    }
}
